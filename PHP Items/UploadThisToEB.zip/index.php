<?php
// index.php – just redirect to login
header('Location: login.php');
exit;
